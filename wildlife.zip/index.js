const mysql = require('mysql');
const querystring = require('querystring');

exports.handler = (event, context, callback) => {
    const connection = mysql.createConnection({
        host: 'database11.cgs3nekxk2zh.us-east-1.rds.amazonaws.com',
        user: 'root',
        password: 'rootroot',
        database: 'database1'
    });

    let params = querystring.parse(event.body);
    let state = String(params['state']);
    let tiger = String(params['tiger']);
    let elephants = String(params['elephants']);
    let leopards = String(params['leopards']);

    // Check if 'update' parameter is present in the request
    if (params['update'] === 'true') {
        // Perform update operation
        const updateQueryString = 'UPDATE animals SET tiger = ?, elephants = ?, leopards = ? WHERE state = ?';
        connection.query(updateQueryString, [tiger, elephants, leopards, state], (error, results, fields) => {
            if (error) {
                // Handle database error
                const reply = `<h1>Error updating the database</h1>`;
                callback(null, reply);
            } else {
                // Successful update
                const reply = `<h1>Update successful</h1>`;
                callback(null, reply);
            }

            // Disconnect from the database
            connection.end();
        });
    } else {
        // Perform create operation
        const createQueryString = 'INSERT INTO animals (state, tiger, elephants, leopards) VALUES (?, ?, ?, ?)';
        connection.query(createQueryString, [state, tiger, elephants, leopards], (error, results, fields) => {
            if (error) {
                // Handle database error
                const reply = `<h1>Error accessing the database</h1>`;
                callback(null, reply);
            } else {
                // Successful create
                const reply = `<h1>Create successful</h1>`;
                callback(null, reply);
            }

            // Disconnect from the database
            connection.end();
        });
    }
};
